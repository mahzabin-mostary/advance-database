﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;

namespace ADMS_Project
{
    public partial class Form11 : Form
    {
        public Form11()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //var reader = DbAccess.GetData($"SELECT * FROM AccountUser WHERE AccountUserName='{txtPassword.Text}' and AccountUserId='{txtUserId.Text}'");
            var reader = DbAccess.GetData($"select  * from reg where userid='{txtUserId.Text}' and  pass='{txtPassword.Text}'");
            if (reader.HasRows == true)
            {
                Dashboard dash = new Dashboard();
                this.Hide();
                dash.ShowDialog();

            }
            else
            {
                MessageBox.Show(" not successful");
            }
        
        }
 

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
               txtPassword.UseSystemPasswordChar = false;


            }
            else
            {
                txtPassword.UseSystemPasswordChar = true;


            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Registration reg = new Registration();
            reg.ShowDialog();
        }
    }
}
