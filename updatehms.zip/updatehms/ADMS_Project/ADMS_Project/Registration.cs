﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using Oracle.ManagedDataAccess.Client;
 
namespace ADMS_Project
{
    public partial class Registration : Form
    {
        
        public Registration()
        {
            InitializeComponent();
        }

       public void label4_Click(object sender, EventArgs e)
        {

        }

     public void button1_Click(object sender, EventArgs e)
        {
            
            string insertReg = $"insert into  reg(userid, name,mail,pass) values('{textBox1.Text}', '{textBox2.Text}', '{textBox3.Text}', '{textBox4.Text}')";

            DbAccess.crud(insertReg);
            DbAccess.Connection.Close();


             Form11 dash = new Form11();
            this.Hide();

            dash.ShowDialog();

            MessageBox.Show("Successfully  registration!");
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {
            Form11 dash = new Form11();
            this.Hide();

            dash.ShowDialog();
        }
    }
}
