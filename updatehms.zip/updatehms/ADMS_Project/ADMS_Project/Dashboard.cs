﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ADMS_Project
{
    public partial class Dashboard : Form
    {
        public Dashboard()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

         AddDoctor  doc = new AddDoctor();
            doc.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
          AddPatient1 Patient = new AddPatient1();
            Patient.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
           AddRoom room = new AddRoom();
           room.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            deletepatient doc = new deletepatient();

             this.Hide();
             doc.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            DeleteRoom  room = new  DeleteRoom();


           room.ShowDialog();

        }

        private void button6_Click(object sender, EventArgs e)
        {
           UpdateRoom room = new UpdateRoom();


            room.ShowDialog();
        }
    }
}
