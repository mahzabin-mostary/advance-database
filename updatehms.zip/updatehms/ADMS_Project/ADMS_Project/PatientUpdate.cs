﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ADMS_Project
{
    public partial class PatientUpdate : Form
    {
        public PatientUpdate()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void PatientUpdate_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string insertReg = "update  patient  set  name='" + textBox2.Text + "',gender='" + textBox3.Text + "',address='" + textBox4.Text + "' ,contactno='" + textBox5.Text + "',age='" + textBox6.Text + "',schedule='" + textBox7.Text + "'  where  patientid='" + textBox1.Text + "'";
            DbAccess.crud(insertReg);
            DbAccess.Connection.Close();




            MessageBox.Show("Successfully  update.....!");
        }
    }
}
