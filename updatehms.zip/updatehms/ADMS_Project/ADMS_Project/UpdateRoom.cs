﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using Oracle.ManagedDataAccess.Client;

namespace ADMS_Project
{
    public partial class UpdateRoom : Form
    {
        public UpdateRoom()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // string insertReg = $" update into   room(roomid, roomno,hosid,roomtype) values('{textBox1.Text}', '{textBox2.Text}', '{textBox3.Text}', '{textBox4.Text}')";
            string  updateroom = "update room set  roomno='" + textBox2.Text + "',hosid='" + textBox3.Text + "', roomtype='" + textBox4.Text + "'  where  roomid='" + textBox1.Text + "'";
            DbAccess.crud(updateroom);
            DbAccess.Connection.Close();




            MessageBox.Show("Successfully  update.....!");
        }
    }
}
