﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using Oracle.ManagedDataAccess.Client;

namespace ADMS_Project
{
    public partial class AddRoom : Form
    {
        public AddRoom()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string addroom = $"insert into     room(roomid,roomno,availability, book,roomtype ) values('{textBox1.Text}', '{textBox2.Text}', '{textBox3.Text}', '{textBox4.Text}',  '{textBox5.Text}'   )";

            // insert into  ROOM (RoomId,RoomNo, AVAILABILITY ,book,RoomType)
            //string addroom = $"insert into   room(roomid, roomno,availability,book,roomtype) values('{textBox1.Text}', '{textBox2.Text}', '{textBox3.Text}', '{textBox4.Text}'),'{textBox5.Text}'";
           // string addroom = $"insert into   room(roomid, roomno,availability,book,roomtype) values('{textBox1.Text}', '{textBox2.Text}', '{textBox3.Text}', '{textBox4.Text}'),'{textBox5.Text}'";

            DbAccess.crud(addroom);
            DbAccess.Connection.Close();




            MessageBox.Show("Successfully room booked!");
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Dashboard dash = new Dashboard();
            this.Hide();
            dash.ShowDialog();
        }
    }
}
